package com.zespolowka;

import org.junit.Test;
import org.springframework.test.context.ActiveProfiles;

/**
 * Created by Pitek on 2015-02-16.
 */
@ActiveProfiles("test")
public class VerificationTokenTest {
    @Test
    public void shoud_show_main_page() throws Exception {
        //VerificationToken verify=new VerificationToken("abcd");
        //System.out.println(verify.getExpiryDate());

    }
}
