package com.zespolowka.entity.createTest;


public enum ProgrammingLanguages {
    CPP("C++"),
    JAVA("JAVA"),
    PYTHON("PYTHON");

    ProgrammingLanguages(String displayName) {
    }

}
